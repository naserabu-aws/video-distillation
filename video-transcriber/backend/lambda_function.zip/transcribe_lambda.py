import json
import urllib.parse
import boto3
import uuid
import os
from datetime import datetime

# Initialize clients
s3 = boto3.client('s3')
transcribe = boto3.client('transcribe')

def lambda_handler(event, context):
    # Get the object from the event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'])
    
    # Validate the key is in the input-videos/ prefix
    if not key.startswith('input-videos/'):
        print(f"Object {key} not in input-videos/ prefix, skipping")
        return {
            'statusCode': 200,
            'body': json.dumps('File not in input-videos/ prefix')
        }
    
    try:
        # Get object metadata to determine content type
        response = s3.head_object(Bucket=bucket, Key=key)
        content_type = response.get('ContentType', '')
        
        # Determine file extension from content type
        extension = ''
        if 'video/mp4' in content_type.lower():
            extension = 'mp4'
        elif 'video/quicktime' in content_type.lower() or 'video/mov' in content_type.lower():
            extension = 'mov'
        elif 'video/x-msvideo' in content_type.lower():
            extension = 'avi'
        elif 'video/x-ms-wmv' in content_type.lower():
            extension = 'wmv'
        else:
            # Try to get extension from key
            if '.' in key:
                extension = key.split('.')[-1].lower()
        
        # Generate unique job name
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        job_name = f"transcription-{timestamp}-{uuid.uuid4()}"
        
        # Set up media file URI
        media_uri = f"s3://{bucket}/{key}"
        
        # Set up output location
        output_key = key.replace('input-videos/', 'transcriptions/').rsplit('.', 1)[0]
        output_location = f"s3://{bucket}/transcriptions/{os.path.basename(output_key)}"
        
        # Start transcription job
        transcribe_response = transcribe.start_transcription_job(
            TranscriptionJobName=job_name,
            Media={'MediaFileUri': media_uri},
            MediaFormat=extension,
            LanguageCode='en-US',  # Default to English, can be made configurable
            OutputBucketName=bucket,
            OutputKey=f"transcriptions/{os.path.basename(output_key)}.json"
        )
        
        print(f"Started transcription job: {job_name}")
        return {
            'statusCode': 200,
            'body': json.dumps(f"Started transcription job: {job_name}")
        }
    
    except Exception as e:
        print(f"Error processing {key} from bucket {bucket}. Error: {e}")
        raise e 